import sys
sys.path.append('third_party/Matcha-TTS')
from cosyvoice.cli.cosyvoice import CosyVoice, CosyVoice2
from cosyvoice.utils.file_utils import load_wav, load_wav_16k
from transformers import AutoModel, AutoTokenizer
import torch, torchaudio
import json, time, logging
from argparse import ArgumentParser
import sys
sys.path.append("<WavTokenizer-path>")
from encoder.utils import convert_audio
from decoder.pretrained import WavTokenizer
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

## WavTokenizer
config_path = "<WavTokenizer-path>/configs/wavtokenizer_smalldata_frame75_3s_nq1_code4096_dim512_kmeans200_attn.yaml"
model_path = "<WavTokenizer-path>/<your-trained-tokenizer>.ckpt"
wavtokenizer = WavTokenizer.from_pretrained0802(config_path, model_path).to(device)
bandwidth_id = torch.tensor([0])

# initialize cosyvoice model
cosyvoice = CosyVoice2('pretrained_models/CosyVoice2-0.5B', load_jit=False, load_trt=False, fp16=False, device=device)
cosyvoice.frontend.tokenizer = AutoTokenizer.from_pretrained('Qwen/Qwen2.5-0.5B')

# load finetuned checkpoint
ft_ckpt = torch.load('<your-trained-ckpt>.pth')
new_ft_ckpt = {k.replace("module.", ""): v for k, v in ft_ckpt.items()}
cosyvoice.model.llm.load_state_dict(new_ft_ckpt, strict=True)
print(f'loaded finetuned checkpoint!')

# test sample
prompt_speech, sr = torchaudio.load('p232_007.wav')
prompt_text = "The rainbow is a division of white light into many beautiful colors."
text = 'We all have a dream, where the world lives in peace forever.'

prompt_text = cosyvoice.frontend.text_normalize(prompt_text, split=False, text_frontend=True)
text = cosyvoice.frontend.text_normalize(text, split=False, text_frontend=True)

prompt_text_token, prompt_text_token_len = cosyvoice.frontend._extract_text_token(prompt_text)
text_token, text_token_len = cosyvoice.frontend._extract_text_token(text)

prompt_speech = convert_audio(prompt_speech, sr, 24000, 1).to(device)
_, prompt_speech_token= wavtokenizer.encode_infer(prompt_speech, bandwidth_id=bandwidth_id)
prompt_speech_token = prompt_speech_token.squeeze(0)
assert len(prompt_speech_token.shape) == 2, prompt_speech_token.shape

speech_token = cosyvoice.model.llm.inference(text=text.to(device),
                    text_len=torch.tensor([text.shape[1]], dtype=torch.int32).to(device),
                    prompt_text=prompt_text.to(device),
                    prompt_text_len=torch.tensor([prompt_text.shape[1]], dtype=torch.int32).to(device),
                    prompt_speech_token=prompt_speech_token.to(device),
                    prompt_speech_token_len=torch.tensor([prompt_speech_token.shape[1]], dtype=torch.int32).to(device),
                    ).to(device)

features = wavtokenizer.codes_to_features(speech_token)
out_speech = wavtokenizer.decode(features, bandwidth_id=bandwidth_id)
torchaudio.save('output.wav', out_speech, 24000)


