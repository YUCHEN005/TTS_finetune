from cosyvoice.cli.cosyvoice import CosyVoice, CosyVoice2
from cosyvoice.utils.file_utils import load_wav, load_wav_16k
from transformers import AutoTokenizer, AutoModel, Qwen2ForCausalLM
import torch, torchaudio
import json, time, os
import sys
sys.path.append("<WavTokenizer-path>")
from encoder.utils import convert_audio
from decoder.pretrained import WavTokenizer

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
cosyvoice = CosyVoice2('pretrained_models/CosyVoice2-0.5B', load_jit=False, load_trt=False, fp16=False, device=device)
cosyvoice.frontend.tokenizer = AutoTokenizer.from_pretrained('Qwen/Qwen2.5-0.5B')

## WavTokenizer
config_path = "<WavTokenizer-path>/configs/wavtokenizer_smalldata_frame75_3s_nq1_code4096_dim512_kmeans200_attn.yaml"
model_path = "<WavTokenizer-path>/<your-trained-tokenizer>.ckpt"
wavtokenizer = WavTokenizer.from_pretrained0802(config_path, model_path).to(device)
bandwidth_id = torch.tensor([0])

## source speech data
wav_scp_path = "data/wav.scp"
text_path = "data/text"
save_path = 'data.pt'

### data processing and save
dataset, idx = [], 0
with open(wav_scp_path, "r") as w_file, open(text_path, "r") as t_file:
    for w_line, t_line in zip(w_file.readlines(), t_file.readlines()):
        source = w_line.strip().split()[1]
        text = ' '.join(t_line.strip().split()[1:])

        ## text processing using cosyvoice's lm tokenizer (can change by yourself)
        dp = cosyvoice.frontend.text_data_processing(text)
        if dp is None:
            continue

        wav, sr = torchaudio.load(source)
        ## check valid
        num_frames = wav.shape[-1] / sr * 100
        if num_frames < 1 or num_frames > 40960 or wav.shape[1] / sr > 30:
            continue
        
        ## speech processing using wavtokenizer
        wav = convert_audio(wav, sr, 24000, 1).to(device)
        _, speech_token= wavtokenizer.encode_infer(wav, bandwidth_id=bandwidth_id)
        speech_token = speech_token.squeeze(0)
        assert len(speech_token.shape) == 2, speech_token.shape
        speech_token_len = torch.tensor([speech_token.shape[1]], dtype=torch.int32).to(device)
        
        dp['speech_token'] = speech_token
        dp['speech_token_len'] = speech_token_len
        dataset.append(dp)

        
torch.save(dataset, save_path)

